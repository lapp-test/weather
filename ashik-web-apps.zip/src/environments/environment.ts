export const environment = {
    production: false,
    PARSE_APP_ID: 'APLICATION_ID',
    PARSE_JS_KEY: 'JS_KEY',
    serverURL: 'https://parseapi.back4app.com'
  };